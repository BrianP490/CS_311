//CS311 Yoshii dgraph.cpp 
// INSTRUCTION:
//  Complete all the functions you listed in dgraph.h
//  Comment the file completely using How to Comment file.
//  Use HW6-help.docx to finish the functions.
//-------------------------------------------------------

//======================================================
// HW#: HW6 dgraph
// Name: Brian Perez
// File Type: implementation file dgraph.cpp
//========================================================
using namespace std;
#include <iostream>
#include <fstream>
#include <string>
#include "dgraph.h"
//constructor for dgraph class
dgraph::dgraph(){
 // initialize vertexName (blank) and visit numbers (0)    // initialize countUsed to be 0{
  countUsed = 0;  //set the number of used indexes of the Gtable array to 0

  for(int i = 0; i < SIZE; i++)  //loop through and initialize the entire table
    {
      dgraph::Gtable[i].vertexName = ' ';
      dgraph::Gtable[i].visit = 0;
    }
}
//Destructor for dgraph class
dgraph::~dgraph()   // do we have to delete all nodes of slists in table??
// Question: If we do not do this, will the llist destructor be called automatically??? Try it.
{
}
//Purpose: Adds vertexes, outDegrees of each vertex, and adjacent verteces, if any using a text file.
void dgraph::fillTable()  // be sure to read from a specified file
{
  string fname;   //var for file name
  cout << "Enter a file name: ";
  cin >> fname;
  string line;   //var for line from text doc to extract information
  ifstream fin (fname.c_str(), ios::in); // declare and open fname

  int c = 0;  //counter for traversing the table
  if(fin) //if the file is open, copy the first line
      getline(fin, line);    //copy the full line from the text doc into var line
  while(!fin.eof())   //loop until the function reads the whole text file
    {
      Gtable[c].vertexName = line[0];   //the GVertex's name will come from index 0 of line
	Gtable[c].outDegree = line[2] - 48;  //the outDegree will come from the third index of cstring line that is converted to an integer value
      
      if(Gtable[c].outDegree > 0)    //loop to add the adjacent vertices if it has any
	{
	  for(int i = 4; i <= line.size(); i += 2 )   //goes through the rest of the line and add the char to the slist in the Gvertex
	    Gtable[c].adjacentOnes.addRear(line[i]);   //add the char into the slist of Gvertex of a certain Gtable index
	    }
      countUsed++;

      c++;   //increase the counter to move indexes in dgrapg
      getline(fin, line);//copy the full line from the text doc into var line
    }
  fin.close();   //close the text file
}

//Purpose: Displays the Directed Graph. It shows each letter in table format, its out Degree, and all adjacent vertices.
void dgraph::displayGraph() // be sure to display
{// in a really nice table format -- all columns but no unused rows 
  for(int i= 0; i<= countUsed; i++) //loop through the entire dgraph
    {
      if((Gtable[i].vertexName >= 65) && (Gtable[i].vertexName <= 90)) //if the Gvertex has a valid name start displaying 
	{
	  cout << Gtable[i].vertexName << " " << Gtable[i].outDegree << " "; 
	  Gtable[i].adjacentOnes.displayAll(); //show the adjacent vertices
	}
    }
}
//Purpose: To return the out Degree of whatever letter is requested
//Parameter: The requested character that will be searched for.
int dgraph::findOutDegree(char V)// throws exception
{// does not use a loop
  int i = V - 65;    //convert the passed char into an int and store the value in i.V is an int starting from 65 and in order to get the index, subtract by 65 
  //throw an exception if the passed char is not in the table 
  if((i <= -1) || (i > countUsed + 1) || (Gtable[i].vertexName != V))
    throw BadVertex ();
  else
    return Gtable[i].outDegree; //return the outdegree of V
}
//Purpose: to return the adjacent vertices as a slist
//Parameter: the char that the function will find the adjacent vertices of
slist dgraph::findAdjacency(char V)// throws exception
{// does not use a loop
  int i = V - 65; //stores the parameter as an int value
  //throw an exception if the passed char is not in the table 
  if((i <= -1) || (i > countUsed + 1) || (Gtable[i].vertexName != V))
    throw BadVertex ();
  else
    return Gtable[i].adjacentOnes;  //return the adjacent vertices of V
}
